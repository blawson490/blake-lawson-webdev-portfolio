package com.wlawson.coinimagecapture;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraControl;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.MeteringPointFactory;
import androidx.camera.core.TorchState;
import androidx.camera.core.ZoomState;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.objects.DetectedObject;
import com.google.mlkit.vision.objects.ObjectDetection;
import com.google.mlkit.vision.objects.ObjectDetector;
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions;

import java.io.File;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class CameraActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_PERMISSIONS = 10;
    private static final String[] REQUIRED_PERMISSIONS = {Manifest.permission.CAMERA};

    private androidx.camera.view.PreviewView viewFinder;

    private ImageCapture imageCapture;
    
    private TextView side_of_coin;

    private File frontImageFile;
    private File backImageFile;
    private boolean isFrontImageCaptured = false;
    private ImageButton shutterButton;
    private Camera camera;
    private ObjectDetector objectDetector;
    private int centerTolerance;
    private int coinTolerance;
    private ImageView imageView;

    @ExperimentalGetImage
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        viewFinder = findViewById(R.id.viewFinder);
        shutterButton = findViewById(R.id.shutter_button);
        side_of_coin = findViewById(R.id.side_of_coin_TV);
        imageView = findViewById(R.id.imageView);

        if (allPermissionsGranted()) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(
                    this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS);
        }

        shutterButton.setOnClickListener(v -> {
            if (imageCapture != null) {
                File photoFile = new File(getExternalFilesDir(null), "coin_" + System.currentTimeMillis() + ".jpg");

                ImageCapture.OutputFileOptions outputFileOptions = new ImageCapture.OutputFileOptions.Builder(photoFile).build();

                imageCapture.takePicture(outputFileOptions, ContextCompat.getMainExecutor(this), new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(@NonNull ImageCapture.OutputFileResults outputFileResults) {
                        if (!isFrontImageCaptured) {
                            frontImageFile = photoFile;
                            isFrontImageCaptured = true;
                            side_of_coin.setText("Back of Coin");
                            Toast.makeText(CameraActivity.this, "Front of coin captured", Toast.LENGTH_SHORT).show();
                        } else {
                            backImageFile = photoFile;
                            Toast.makeText(CameraActivity.this, "Back of coin captured", Toast.LENGTH_SHORT).show();
                            sendResultAndFinish();
                        }
                    }

                    @Override
                    public void onError(@NonNull ImageCaptureException exception) {
                        Toast.makeText(CameraActivity.this, "Error capturing image: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        ImageButton flashButton = findViewById(R.id.flash_button);
        flashButton.setOnClickListener(v -> {
            toggleTorch(camera);
            if (camera.getCameraInfo().getTorchState().getValue() == TorchState.ON) {
                flashButton.setImageResource(R.drawable.ic_flash_on);
            } else {
                flashButton.setImageResource(R.drawable.ic_flash_off);
            }
        });

        ObjectDetectorOptions options = new ObjectDetectorOptions.Builder()
                .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
                .enableClassification()
                .build();

        objectDetector = ObjectDetection.getClient(options);
        centerTolerance = 30;
        coinTolerance = 50;

        SeekBar zoomSeekBar = findViewById(R.id.zoomSeekBar);

        zoomSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                //For Zoom
                float zoomLevel = (float)progress / 100;
                zoom(zoomLevel);

                coinTolerance = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    @SuppressLint("ClickableViewAccessibility")
    @ExperimentalGetImage
    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);
        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                CameraSelector cameraSelector = new CameraSelector.Builder()
                        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                        .build();

                androidx.camera.core.Preview preview = new androidx.camera.core.Preview.Builder()
                        .build();
                preview.setSurfaceProvider(viewFinder.getSurfaceProvider());

                imageCapture = new ImageCapture.Builder()
                        .setFlashMode(ImageCapture.FLASH_MODE_OFF)
                        .build();

                ImageAnalysis imageAnalysis = new ImageAnalysis.Builder().build();
                imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this), image -> {
                    InputImage inputImage = InputImage.fromMediaImage(Objects.requireNonNull(image.getImage()), image.getImageInfo().getRotationDegrees());
                    objectDetector.process(inputImage)
                            .addOnSuccessListener(detectedObjects -> {
                                for (DetectedObject detectedObject : detectedObjects) {
                                    Rect boundingBox = detectedObject.getBoundingBox();
                                    //Log.d("ImageAnalysis", "BoundingBox: " + boundingBox.toString());
                                    // Check if boundingBox is a probable coin and is centered
                                    if (isPossibleCoin(boundingBox) && isCentered(boundingBox)) {

                                        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                                        if (vibrator != null && vibrator.hasVibrator()) {
                                            new Handler().postDelayed(()-> vibrator.vibrate(100), 200);
                                        }

                                        // Set focus to the center
                                        float centerX = viewFinder.getWidth() / 2f;
                                        float centerY = viewFinder.getHeight() / 2f;
                                        setFocusPoint(new PointF(centerX, centerY), camera);

                                        imageView.setVisibility(View.VISIBLE);
                                    } else {
                                        imageView.setVisibility(View.GONE);
                                    }
                                }
                                image.close();
                            })
                            .addOnFailureListener(e -> image.close());
                });

                cameraProvider.unbindAll();
                camera = cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture, imageAnalysis); // Added imageAnalysis to this

                camera.getCameraControl().enableTorch(true);

                zoom(0.5f);


                viewFinder.setOnTouchListener((v, event) -> {
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        PointF touchPoint = new PointF(event.getX(), event.getY());
                        setFocusPoint(touchPoint, camera);
                    }
                    return true; // return true to consume the event
                });
            } catch (ExecutionException | InterruptedException e) {
                // Handle any errors (usually on a different thread, so use a Handler or similar)
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void zoom(float zoom) {
        ZoomState zoomState = camera.getCameraInfo().getZoomState().getValue();
        if (zoomState != null) {
            float maxZoom = zoomState.getMaxZoomRatio();
            float zoomToSet = maxZoom * zoom;
            camera.getCameraControl().setZoomRatio(zoomToSet);
        }
    }

    private void setFocusPoint(PointF point, Camera camera) {
        MeteringPointFactory factory = viewFinder.getMeteringPointFactory();
        MeteringPoint focusPoint = factory.createPoint(point.x, point.y);

        FocusMeteringAction action = new FocusMeteringAction.Builder(focusPoint)
                .setAutoCancelDuration(5, TimeUnit.SECONDS) // After 5 seconds metering will return to normal
                .build();

        CameraControl cameraControl = camera.getCameraControl();
        cameraControl.startFocusAndMetering(action);
    }

    private void toggleTorch(Camera camera) {
        if (camera.getCameraInfo().getTorchState().getValue() == TorchState.OFF) {
            camera.getCameraControl().enableTorch(true);
        } else {
            camera.getCameraControl().enableTorch(false);
        }
    }

    public int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private boolean isPossibleCoin(Rect boundingBox) {
        int detectedArea = boundingBox.width() * boundingBox.height();

        int overlaySize = dpToPx(250);
        int expectedArea = (int) (Math.PI * Math.pow(overlaySize / 2, 2));

        // Let's widen the tolerance
        int tolerance = coinTolerance;
        int lowerBound = expectedArea - (expectedArea * tolerance / 100);
        int upperBound = expectedArea + (expectedArea * tolerance / 100);

        boolean isCorrectSize = detectedArea >= lowerBound && detectedArea <= upperBound;

        return isCorrectSize;
    }


    private boolean isCentered(Rect boundingBox) {
        int tolerance = dpToPx(centerTolerance);

        // Check if boundingBox is aligned with the left edge of the viewfinder
        boolean alignedLeft = Math.abs(boundingBox.left) < tolerance;

        // Check if boundingBox is aligned with the top edge of the viewfinder
        boolean alignedTop = Math.abs(boundingBox.top) < tolerance;

        // Check if boundingBox is aligned with the right edge of the viewfinder
        boolean alignedRight = Math.abs(viewFinder.getWidth() - boundingBox.right) < tolerance;

        // Check if boundingBox is aligned with the bottom edge of the viewfinder
        boolean alignedBottom = Math.abs(viewFinder.getHeight() - boundingBox.bottom) < tolerance;

        return alignedLeft && alignedTop && alignedRight && alignedBottom;
    }

    private boolean allPermissionsGranted() {
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(getBaseContext(), permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    @ExperimentalGetImage
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera();
            } else {
                Toast.makeText(this, "Permissions not granted by the user.", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    private void sendResultAndFinish() {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("front_image_path", frontImageFile.getAbsolutePath());
        resultIntent.putExtra("back_image_path", backImageFile.getAbsolutePath());
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}
