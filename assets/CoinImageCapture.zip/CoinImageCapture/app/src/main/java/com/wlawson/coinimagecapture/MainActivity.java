package com.wlawson.coinimagecapture;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    // Constants to represent the two states of the coin.
    private static final int HEADS = 1;
    private static final int TAILS = 2;

    // Image paths for user taken images
    private String frontImagePath = null;  // Path for the HEADS
    private String backImagePath = null;   // Path for the TAILS

    // Storing Image for optimization
    private Bitmap frontImageBitmap;
    private Bitmap backImageBitmap;
    // Variables to track previous touch position and the current rotation of the coin.
    private float lastX;
    private float rotationDegrees = 0;
    private int currentCoinState = HEADS;

    // UI elements.
    private ImageView coinImageView;

    // VelocityTracker helps in tracking velocity of touch movement.
    private VelocityTracker velocityTracker = null;

    // An animator that simulates momentum when the touch is released.
    private ValueAnimator momentumAnimator = null;

    // Image Paths
    private static final String FRONT_IMAGE_PATH = "front_image_path";
    private static final String BACK_IMAGE_PATH = "back_image_path";

    // Result Launcher for Camera Activity
    ActivityResultLauncher<Intent> cameraActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null) {
                        frontImagePath = data.getStringExtra(FRONT_IMAGE_PATH);
                        backImagePath = data.getStringExtra(BACK_IMAGE_PATH);

                        // Store front image for optimizing runtime
                        frontImageBitmap = BitmapFactory.decodeFile(frontImagePath);
                        frontImageBitmap = rotateCustomImage(frontImageBitmap, "front");

                        // Store back image for optimizing runtime
                        backImageBitmap = BitmapFactory.decodeFile(backImagePath);
                        backImageBitmap = mirrorImage(backImageBitmap);
                        backImageBitmap = rotateCustomImage(backImageBitmap, "back");

                        // Spin coin 4 times
                        // Cancel any ongoing momentum animation.
                        if (momentumAnimator != null && momentumAnimator.isRunning()) {
                            momentumAnimator.cancel();
                        }

                        // Spin coin 4 times
                        float currentRotation = coinImageView.getRotationY();
                        float targetRotation = currentRotation + 720;
                        momentumAnimator = ValueAnimator.ofFloat(currentRotation, targetRotation);
                        momentumAnimator.addUpdateListener(animation -> {
                            float animatedValue = (float) animation.getAnimatedValue();
                            setRotationAndImageBasedOnDegrees(animatedValue);
                        });
                        momentumAnimator.setDuration(1000); // 4 seconds for 4 spins, adjust as needed
                        momentumAnimator.setInterpolator(new LinearInterpolator());
                        momentumAnimator.start();
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views and set touch listeners.
        initViews();
    }

    private void initViews() {
        // Find views from the layout.
        coinImageView = findViewById(R.id.iv_coin);
        Button cameraButton = findViewById(R.id.open_camera_button);

        cameraButton.setOnClickListener((v -> launchCameraActivity()));

        RelativeLayout container = findViewById(R.id.container);

        // Set touch listener on the container.
        container.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    handleActionDown(event);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    handleActionMove(event);
                    return true;
                case MotionEvent.ACTION_UP:
                    handleActionUp(v);
                    return true;
            }
            return false;
        });
    }

    private void launchCameraActivity() {
        cameraActivityResultLauncher.launch(new Intent(this, CameraActivity.class));
    }

    private void handleActionDown(MotionEvent event) {
        // If the animator is running (i.e. coin is moving with momentum), cancel it.
        if (momentumAnimator != null && momentumAnimator.isRunning()) {
            momentumAnimator.cancel();
        }

        // Initialize or clear the velocity tracker.
        velocityTracker = velocityTracker != null ? velocityTracker : VelocityTracker.obtain();
        velocityTracker.clear();
        velocityTracker.addMovement(event);

        // Capture the initial touch point.
        lastX = event.getX();
        // Capture the current rotation of the coin.
        rotationDegrees = coinImageView.getRotationY();
    }

    private void handleActionMove(MotionEvent event) {
        // Update the velocity tracker with the new motion event.
        velocityTracker.addMovement(event);
        velocityTracker.computeCurrentVelocity(1000);

        // Calculate the change in touch position.
        float deltaX = cappedDeltaX(event.getX() - lastX);
        updateRotation(deltaX);

        // Logging for debugging purposes.
        Log.i("deltaX", "DeltaX:" + deltaX);
        Log.i("Rotation Degrees", "Rotation Degrees: " + rotationDegrees);

        // Update the coin's rotation and image based on the calculated rotation.
        setRotationAndImageBasedOnDegrees(rotationDegrees);
        // Update the last touch position.
        lastX = event.getX();
    }

    private void handleActionUp(View v) {
        // On releasing the touch, calculate the final velocity.
        float velocityX = velocityTracker.getXVelocity();
        // Apply the momentum animation based on the velocity.
        applyMomentum(velocityX);

        // Clean up the velocity tracker.
        velocityTracker.recycle();
        velocityTracker = null;
        // Simulate a click event on the view.
        v.performClick();
    }

    private void updateRotation(float deltaX) {
        // Normalize rotation to range [0, 360).
        float normalizedRotation = rotationDegrees % 360;
        if (normalizedRotation < 0) normalizedRotation += 360;

        // Compute a damping factor to adjust rotation based on current angle.
        float dampingFactor = computeDamping(normalizedRotation);
        float targetRotation = rotationDegrees + deltaX * dampingFactor;

        // Smooth out the rotation change to make it more natural.
        rotationDegrees += 0.3f * (targetRotation - rotationDegrees);
        rotationDegrees = (rotationDegrees % 360 + 360) % 360;
    }

    private void setRotationAndImageBasedOnDegrees(float rotationDegrees) {
        // Normalize rotation to range [0, 360).
        float normalizedRotation = normalizeRotation(rotationDegrees);
        // Apply the rotation to the coin image.
        coinImageView.setRotationY(rotationDegrees);

        // Depending on the rotation angle, update the coin's image.
        if (isTailRotation(normalizedRotation)) {
            setCoinImage(TAILS);
        } else {
            setCoinImage(HEADS);
        }
    }

    private float normalizeRotation(float rotationDegrees) {
        // Normalize rotation to range [0, 360).
        float normalizedRotation = rotationDegrees % 360;
        return normalizedRotation < 0 ? normalizedRotation + 360 : normalizedRotation;
    }

    private boolean isTailRotation(float normalizedRotation) {
        // Check if the coin should show the TAILS image based on rotation angle.
        return normalizedRotation > 90 && normalizedRotation < 270;
    }

    private void setCoinImage(int coinState) {
        if (coinState == TAILS && currentCoinState != TAILS) {
            if (backImagePath != null) {
                // Load user image for TAILS and mirror it
                coinImageView.setImageBitmap(backImageBitmap);
            } else {
                // Load default drawable for TAILS and mirror it
                Bitmap tailsBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.img_tails);
                coinImageView.setImageBitmap(mirrorImage(tailsBitmap));
            }
            currentCoinState = TAILS;
        } else if (coinState == HEADS && currentCoinState != HEADS) {
            if (frontImagePath != null) {
                // Load user image for HEADS
                coinImageView.setImageBitmap(frontImageBitmap);
            } else {
                // Use default drawable for HEADS
                coinImageView.setImageResource(R.drawable.img_heads);
            }
            currentCoinState = HEADS;
        }
    }


    private float cappedDeltaX(float deltaX) {
        // Limit the maximum change in touch position to prevent excessive rotation.
        final float MAX_DELTA_X = 50;
        return Math.min(Math.max(deltaX, -MAX_DELTA_X), MAX_DELTA_X);
    }

    private void applyMomentum(float velocityX) {
        // Calculate how much the coin should rotate based on the velocity.
        float rotationToAdd = velocityX * 0.015f;
        float targetRotation = rotationDegrees + rotationToAdd;

        // Create and start an animation to simulate the coin's momentum.
        momentumAnimator = ValueAnimator.ofFloat(rotationDegrees, targetRotation);
        momentumAnimator.addUpdateListener(animation -> {
            float animatedValue = (float) animation.getAnimatedValue();
            setRotationAndImageBasedOnDegrees(animatedValue);
        });
        momentumAnimator.setDuration(1000);
        momentumAnimator.setInterpolator(new DecelerateInterpolator());
        momentumAnimator.start();
    }

    private float computeDamping(float rotation) {
        // Calculate a damping factor based on how close the coin is to a full rotation.
        float distanceToEdge = Math.min(Math.abs(rotation - 90), Math.abs(rotation - 270));
        float baseDamping = (float) Math.pow(Math.cos(Math.toRadians(distanceToEdge / 3)), 4);

        return Math.abs(rotation) > 720 ? 0.01f + 0.9f * baseDamping : 0.1f + 0.9f * baseDamping;
    }

    private Bitmap mirrorImage(Bitmap bitmap) {
        Matrix matrix = new Matrix();
        matrix.preScale(-1.0f, 1.0f);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    private Bitmap rotateCustomImage(Bitmap bitmap, String side) {
        Matrix matrix = new Matrix();
        if (Objects.equals(side, "front")) {
            matrix.postRotate(90);
        } else {
            matrix.postRotate(-90);
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }
}